package com.javarabbitmq.springbootrabbitmq;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootRabbitmqApplicationTests {

	@Test
	void contextLoads() {
	}

}
